package edu.ncsu.monopoly;

public interface TradeDialog {
    TradeDeal getTradeDeal();
}
