
public class Constant  implements IOperator{

	@Override
	public int Calculate(int constant, Expression left, Expression right) {
		
		return constant;
				
	}

	
	
	
}
