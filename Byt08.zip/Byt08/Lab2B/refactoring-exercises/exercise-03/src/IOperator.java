
 interface IOperator {
	
	
	int Calculate(int constant,Expression left, Expression  right);

}
